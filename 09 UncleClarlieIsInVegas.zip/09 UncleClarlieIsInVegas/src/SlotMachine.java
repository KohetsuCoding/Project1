import java.text.*;
public class SlotMachine {
	private String slotName;
	private int balance;
	private int numWins;
	private int numPlays;
	private int numJackpot;
	private int amountJackpotPays;
	private int amountRegularWin;
	
	public SlotMachine (String slotName, int balance, int numWins, int numJackpot, int amountJackpotPays, int amountRegularWin) {
		setName(slotName);
		setBalance(balance);
		setWins(numWins);
		setNumJackpot(numJackpot);
		setAmountRegularWin(amountRegularWin);
		setAmountJackpotPays(amountJackpotPays);
	}
	
    public boolean isJackpot(){
        return (numPlays % numJackpot == 0);
    }

    public boolean isWin(){
        return (numPlays % numWins == 0);
    }
	
	public String getName() {
		return slotName;
	}
	public void setName(String slotName) {
		this.slotName = slotName;
	}
	
	
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	
	public int getWins() {
		return numWins;
	}
	public void setWins(int numWins) {
		this.numWins = numWins;
	}
	
	public int getNumJackpot() {
		return numJackpot;
	}
	public void setNumJackpot(int numJackpot) {
		this.numJackpot = numJackpot;
	}
	
	public int getAmountJackpotPays() {
		return amountJackpotPays;
	}
	public void setAmountJackpotPays(int amountJackpotPays) {
		this.amountJackpotPays = amountJackpotPays;
	}
	
	public int getAmountRegularWin() {
		return amountRegularWin;
	}
	public void setAmountRegularWin(int amountRegularWin) {
		this.amountRegularWin = amountRegularWin;
	}
	
	public int getNumPlays() {
		return numPlays;
	}
	public void setNumPlays(int numPlays) {
		this.numPlays = numPlays;
	}
	
	 public String toString(){
		 DecimalFormat df = new DecimalFormat("$###,###,###,##0.00");
		 return slotName + "," + df.format(balance) + "\nPlays:" +numPlays;
	 }
	
	
}//End Class

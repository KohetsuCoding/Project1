
public class Date {
	
	private int day;
	private int month;
	private int year;
	
	public Date (int d, int m, int y) {
		day = d;
		month = m;
		year = y;
	}
	

	public Date(String dob) {
		// TODO Auto-generated constructor stub
	}


	public int getDay() {
		return day;
	}
	public void setDay(int d) {
		if(d >= 1 && d <= 31) {
		day = d;
		}
	}
	
	public int getMonth() {
		return month;
	}
	public void setMonth(int m) {
		if(m >= 1 && m <= 12) {
		month = m;
		}
	}
	
	public int getYear() {
		return year;
	}
	public void setYear(int y) {
		if(y >= 1900 && y <= 2021) {
		year = y;
		}
	}
	
	public String toString() {
		String result;
		result = day + "/" + month + "/" + year;
		return result;
	}
	
	
	
}//End Class

import java.util.*;
public class UncleCharlieIsInVegas {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Player players[] = new Player[50];
		SlotMachine machines[] = new SlotMachine[50];
		
		Name name1 = new Name ("Uncle", "D", "Charlie");
		Date date1 = new Date ("02,21,2019");
		
		players[0] = new Player(name1, date1, 100);
		machines[0] = new SlotMachine("Lucky 7", 5000, 10000, 40000, 10, 5);
		machines[1] = new SlotMachine("Lucky Lotto", 55000, 100000, 75000, 50, 25);
        machines[2] = new SlotMachine("Purple People Eater", 1000, 50, 40, 5, 2);
		
		Player currentPlayer = players[0];
		SlotMachine currentMachine = machines[0];
		
		int loop = 1;
		do {
		display(currentPlayer, currentMachine);
		String option = sc.next();
		int index = 0;
		
		switch(option) {
		case "1":
			System.out.println("Which player do you choose?");
			index = sc.nextInt() - 1;
			if (players[index].getBalance() <1) {
				System.out.println("This player has insufficient funds. Pick another player.");
				break;
			}
			currentPlayer = players[index];
			break;
		case "2":
			System.out.println("Which machine do you choose?");
			index = sc.nextInt()-1;
			if(machines[index].getBalance()< machines[index].getAmountRegularWin()) {
				System.out.println("This machine has insufficient funds.  Pick a different machine.");
				break;
			}
			currentMachine = machines[index];
			break;
		case "3":
			newPlayer(players);
			break;
		case "4":
			newMachine(machines);
			break;
		case "5":
			play(currentPlayer, currentMachine);
			break;
		case "6":
			System.out.println("Thank you for playing!");
			loop = 0;
			break;
		default:
			System.out.println("Invalid entry. Please try again.");
			break;
			}
		} while(loop != 0);
	}//End Main
	
	public static void display(Player currentPlayer, SlotMachine currentMachine){
        System.out.println("Current Player: " + currentPlayer.getName() + "\nDate of Birth: " + currentPlayer.getDOB() + "\nCurrent Balance: $" + currentPlayer.getBalance() + "\nCurrent Machine: " + currentMachine.getName());
        System.out.println("[1] Select a player \n[2] Select a machine \n[3] Add Player \n[4] Add Machine \n[5] Play \n[6] Exit \n");
	}
        public static int indexLast(Object[] arr){
            for(int i = 0; i < arr.length; ++i){
                if( arr[i] == null ) return i;
            }
            return -1;
        }
       
        public static void newPlayer(Player[] players){
            if(indexLast(players) == -1){
                System.out.println("The Casino is full. No more players can enter the casino.");
                return;
            }
            
            Scanner sc = new Scanner(System.in);
            System.out.println("What is the first name of this new player?");
            String firstName = sc.next();
            System.out.println("What is the middle initial of this new player?");
            String middleName = sc.next();
            System.out.println("What is the last name of this new player?");
            String lastName = sc.next();
            System.out.println("What is the date of birth of this new player?");
            Date dob = new Date (sc.next());
            System.out.println("What is the money balance of this new player?");
            int balance = sc.nextInt();
            
            Name name2 = new Name (firstName, middleName, lastName);
            
            players[indexLast(players)] = new Player(name2, dob, balance);
        }
        
        public static void newMachine(SlotMachine[] machines){
            if(indexLast(machines) == -1){
                System.out.println("The Casino is full. No more machines can be brought into the casino.");
                return;
            }
            Scanner sc = new Scanner(System.in);
            System.out.println("What is the name of this slot?");
            String name = sc.next();
            System.out.println("What is the balance of this slot?");
            int balance = sc.nextInt();
            System.out.println("How many plays does it take for someone to win the jackpot?");
            int numJackpot = sc.nextInt();
            System.out.println("How many plays does it take for someone to win normally?");
            int numWins = sc.nextInt();
            System.out.println("What is the jackpot payout of this slot?");
            int amountJackpotPays = sc.nextInt();
            System.out.println("What is the normal payout of this slot?");
            int amountRegularWin= sc.nextInt();

            machines[indexLast(machines)] = new SlotMachine(name, balance, numJackpot,amountJackpotPays, numWins, amountRegularWin);
        }
        
        public static void print(Object[] arr){
            for(int i = 0; i < arr.length; ++i){
                if(arr[i] == null)
                    continue;
                System.out.println("[" + (i+1) + "] " + arr[i]);
            }
        }
        
        public static void play(Player player, SlotMachine machine){
            Scanner sc = new Scanner(System.in);

            if(player.getBalance() < 1){
                System.out.println("This player has insufficient funds. Pick a different player.");
                return;
            }
            if(machine.getBalance() < machine.getAmountRegularWin()){
                System.out.println("This machine has insufficient funds. Pick a different machine.");
                return;
            }
            
            player.play(machine);
            
            if(machine.isJackpot()){
                System.out.println("Congratulations! " + machine.getName().toUpperCase() + " JACKPOT!");
                player.setBalance( player.getBalance() + machine.getAmountJackpotPays() );
                machine.setBalance( machine.getBalance() - machine.getAmountJackpotPays() );
            }
            else if(machine.isWin()){
                System.out.println("You won $" + machine.getAmountRegularWin()+ " on the " + machine.getName() + " machine.");
                player.setBalance( player.getBalance() + machine.getAmountRegularWin() );
                machine.setBalance( machine.getBalance() - machine.getAmountRegularWin() );
            }else{
                System.out.println("Sorry. Better luck next time " + player.getName()+ ".");
            }
        }
	}//End Class


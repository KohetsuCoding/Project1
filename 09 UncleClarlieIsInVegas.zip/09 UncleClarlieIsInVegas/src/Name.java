
public class Name {
	private String firstName;
	private String middleName;
	private String lastName;
	
	public Name(String fullName) {
        String temp[] = fullName.split(" ");
        if (temp.length < 3){
            setFirstName(temp[0]);
            setLastName(temp[1]);
        }else{ 
            setFirstName(temp[0]);
            setMiddleName(temp[1]);
            setLastName(temp[2]);
        }
    }
	
	public Name(String firstName, String lastName) {
        this.setFirstName(firstName);
        this.setLastName(lastName);
    }

    public Name(String firstName, String middleName, String lastName) {
        this.setFirstName(firstName);
        this.setMiddleName(middleName);
        this.setLastName(lastName);
    }

	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String fName) {
		if (fName.length() > 0) {
			char c = fName.charAt(0);
			fName = fName.toLowerCase().substring(1);
			this.firstName = c + fName;
		}
	}
	
	
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String mName) {
		if (mName.length() > 0) {
			char c = mName.charAt(0);
			mName = mName.toLowerCase().substring(1);
			this.middleName = c + mName;
		}
	}
	
	
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lName) {
		if (lName.length() > 0) {
			char c = lName.charAt(0);
			lName = lName.toLowerCase().substring(1);
			this.lastName = c + lName;
		}
	}
	
	
	public String toString() {
		if (middleName != "")
			return firstName + " " + middleName + ". " + lastName;
		else
			return firstName + " " + lastName;
	}
	
}

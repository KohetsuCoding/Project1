import java.text.*;
public class Player {

	private Name name;
	private Date dob;
	private int moneyBalance;
	
	public Player() {
		name = new Name("", "", "");
		dob = new Date(10,18,1994);
	}
	
	public Player(Name name, Date dob, int moneyBalance) {
		setName(name);
		setDOB(dob);
		setBalance(moneyBalance);
	}
	

	public Name getName() {
		return name;
	}
	public void setName(Name name) {
		this.name = name;
}
	
	public Date getDOB() {
		return dob;
	}
	public void setDOB(Date dob) {
		this.dob = dob;
	}
	
	public int getBalance() {
		return moneyBalance;
	}
	public void setBalance(int moneyBalance) {
		this.moneyBalance = moneyBalance;
	}
	
	public void play(SlotMachine machine){
        this.moneyBalance--;
        machine.setBalance(machine.getBalance() + 1);
        machine.setNumPlays(machine.getNumPlays() + 1);
    }
	
	public String toString() {
		DecimalFormat df = new DecimalFormat("$###,###,###,##0.00");
		return name + "\nDate of Birth: " + dob + "\nBalance: $" + df.format(moneyBalance);
		}



	}//end Class
